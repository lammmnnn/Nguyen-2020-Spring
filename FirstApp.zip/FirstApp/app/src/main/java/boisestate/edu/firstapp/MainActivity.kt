package boisestate.edu.firstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.AbsListView
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.util.concurrent.ThreadLocalRandom

class MainActivity : AppCompatActivity() {

    lateinit var numEditText1:EditText
    lateinit var numEditText2: EditText
    lateinit var randomButton: Button
    lateinit var concatButton: Button
    lateinit var addButton: Button
    lateinit var outputTextView: TextView
    lateinit var outputTextView2: TextView
    lateinit var outputTextView3: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        numEditText1 = findViewById(R.id.numEditText1)
        numEditText2 = findViewById(R.id.numEditText2)
        randomButton = findViewById(R.id.randomButton)
        concatButton = findViewById(R.id.concatButton)
        addButton = findViewById(R.id.addButton)
        outputTextView = findViewById(R.id.outputTextView)
        outputTextView2 = findViewById(R.id.outputTextView2)
        outputTextView3 = findViewById(R.id.outputTextView3)



        randomButton.setOnClickListener{
            var min:Int = 0
            var max:Int = 0
            if (numEditText1.text.isNotEmpty() && numEditText2.text.isNotEmpty()) {
                min = numEditText1.text.toString().toInt()
                max = numEditText2.text.toString().toInt()
            }
            var randomResult:Int = 0
            if (min > max) {
                randomResult = ThreadLocalRandom.current().nextInt(max, min + 1)
                numEditText1.setText("$max")
                numEditText2.setText("$min")
            } else {
                randomResult = ThreadLocalRandom.current().nextInt(min, max + 1)
            }
            outputTextView.text = "Result: $randomResult"

        }

        concatButton.setOnClickListener{
            outputTextView2.text = "Result: ${numEditText1.text}${numEditText2.text}"
        }

        addButton.setOnClickListener{
            var min:Int = 0
            var max:Int = 0
            if (numEditText1.text.isNotEmpty()) {
                min = numEditText1.text.toString().toInt()
            }
            if (numEditText2.text.isNotEmpty()) {
                max = numEditText2.text.toString().toInt()
            }
            outputTextView3.text = "Result: ${min + max}"

        }
    }
}
