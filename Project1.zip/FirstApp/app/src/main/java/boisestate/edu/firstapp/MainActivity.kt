package boisestate.edu.firstapp

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    var acclist: ArrayList<Account> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val loginButton: Button = findViewById(R.id.submitButton)
        val signupButton: Button = findViewById(R.id.signupButton)
        val usernameEditText:EditText = findViewById(R.id.usernameText)
        val passwordEditText:EditText = findViewById(R.id.passwordText)
        val errorText:TextView = findViewById(R.id.errorText)

        loginButton.setOnClickListener {
            if (usernameEditText.text.toString().isNotBlank()) {
                var accExisted: Boolean = false
                var correctPassword: Boolean = false
                loop@ for (i in acclist) {
                    if (i.username.toString() == usernameEditText.text.toString()) {
                        accExisted = true
                        if (i.password.toString() == passwordEditText.text.toString()) {
                            correctPassword = true
                            val loginIntent: Intent = Intent(this, LoginDisplayActivity::class.java)
                            loginIntent.putExtra("account", i)
                            startActivity(loginIntent)
                        }
                        break@loop
                    }
                }
                if (!accExisted) {
                    errorText.setText("Username not in our system")
                } else if (!correctPassword) {
                    errorText.setText("Incorrect password")
                }
            } else {
                errorText.setText("Username can't be blank")
            }
        }

        signupButton.setOnClickListener {
            val signupIntent: Intent = Intent(this, SignupActivity::class.java)
            signupIntent.putExtra("acclist", acclist)
            startActivityForResult(signupIntent, 12)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            if (data != null) {
                val newAccount: Account = data.getSerializableExtra("newAccount") as Account
                acclist.add(newAccount)
                Log.d("EA", "Account is created!")
            }
        }
    }
}
