package boisestate.edu.firstapp

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity

import kotlinx.android.synthetic.main.activity_signup.*

class SignupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
        setSupportActionBar(toolbar)

        val checkusernameButton: Button = findViewById(R.id.checkusernameButton)
        val submitsignupButton: Button = findViewById(R.id.submitsignupButton)
        val cancelButton: Button = findViewById(R.id.cancelButton)
        val usernamesEditText: EditText = findViewById(R.id.usernamesignupText)
        val passwordsEditText: EditText = findViewById(R.id.passwordsignupText)
        val repasswordsEditText: EditText = findViewById(R.id.rePasswordText)
        val acclist:ArrayList<Account> = intent.getSerializableExtra("acclist") as ArrayList<Account>


        checkusernameButton.setOnClickListener {
            if (usernamesEditText.text.toString().length in 6..12) {
                var accIsUsed: Boolean = false
                loop@ for (i in acclist) {
                    if (i.username.toString().equals(usernamesEditText.text.toString())) {
                        accIsUsed = true
                        checkusernameButton.setBackgroundColor(Color.RED)
                        break@loop
                    }
                }
                if (!accIsUsed) {
                    checkusernameButton.setBackgroundColor(Color.GREEN)
                }
            } else {
                checkusernameButton.setBackgroundColor(Color.RED)
            }
        }

        submitsignupButton.setOnClickListener {
            if (usernamesEditText.text.toString().length in 6..12 && passwordsEditText.text.toString().length in 6..12
                && passwordsEditText.text.toString() == repasswordsEditText.text.toString()) {
                var accIsUsed: Boolean = false
                loop@ for (i in acclist) {
                    if (i.username.toString().equals(usernamesEditText.text.toString())) {
                        accIsUsed = true
                        checkusernameButton.setBackgroundColor(Color.RED)
                        break@loop
                    }
                }
                if (!accIsUsed) {
                    val newAccount: Account = Account(
                        usernamesEditText.text.toString(),
                        passwordsEditText.text.toString()
                    )
                    val returnIntent:Intent = Intent()
                    returnIntent.putExtra("newAccount", newAccount)
                    setResult(Activity.RESULT_OK, returnIntent)
                    finish()
                }
            }
        }

        cancelButton.setOnClickListener {
            setResult(Activity.RESULT_CANCELED)
            finish()
        }

        fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }
    }

}
