package boisestate.edu.firstapp

import java.io.Serializable

class Account(val username:String, val password:String/*, val name:String*/):Serializable {
}