package boisestate.edu.firstapp

import android.os.Bundle
import android.widget.TextView
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity

import kotlinx.android.synthetic.main.activity_login_display.*

class LoginDisplayActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_display)
        setSupportActionBar(toolbar)

        val account:Account = intent.getSerializableExtra("account") as Account

        val usernametview: TextView = findViewById(R.id.usernameTextView)
        val passwordtview: TextView = findViewById(R.id.passwordTextView)

        usernametview.text = account.username
        passwordtview.text = account.password

        fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }
    }

}
