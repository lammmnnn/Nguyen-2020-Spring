package boisestate.edu.finalproject

import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast


class IngameScreenActivity : AppCompatActivity() {


    private var cellArray = arrayOf<ArrayList<String>>()
    private lateinit var mp: MediaPlayer
    private var muted: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ingame_screen)

        mp = MediaPlayer.create(this, R.raw.msm)
        mp.isLooping = true
        mp.setVolume(0.3f, 0.3f)
        mp.start()

        for (i in 1..9) {
            cellArray += arrayListOf<String>()
        }

        val backbutton: ImageButton = findViewById(R.id.exitButton)

        backbutton.setOnClickListener {
            val menuIntent: Intent = Intent(this, MainActivity::class.java)
            mp.stop()
            startActivity(menuIntent)
        }
    }

    fun soundButtonClick(view: View) {
        if (!muted) {
            mp.setVolume(0.0f, 0.0f)
            muted = true
        } else {
            mp.setVolume(0.3f, 0.3f)
            muted = false
        }
    }


    fun fieldClick(view: View) {
        val currentInfoView: TextView = findViewById(R.id.currentInfoView)
        val buttonClicked = view as Button
        if (winner == -1) {
            if (buttonClicked.id == R.id.button1 || buttonClicked.id == R.id.button2 || buttonClicked.id == R.id.button3
                || buttonClicked.id == R.id.button4 || buttonClicked.id == R.id.button5 || buttonClicked.id == R.id.button6
                || buttonClicked.id == R.id.button7 || buttonClicked.id == R.id.button8 || buttonClicked.id == R.id.button9
            ) {
                var cellID = 0
                when (buttonClicked.id) {
                    R.id.button1 -> cellID = 0
                    R.id.button2 -> cellID = 1
                    R.id.button3 -> cellID = 2
                    R.id.button4 -> cellID = 3
                    R.id.button5 -> cellID = 4
                    R.id.button6 -> cellID = 5
                    R.id.button7 -> cellID = 6
                    R.id.button8 -> cellID = 7
                    R.id.button9 -> cellID = 8
                }
                gameplay(cellID, buttonClicked)
            } else if (buttonClicked.id == R.id.selectSButton) {
                if (currentPlayer == 1 && p1PieceLeft.get(0) > 0) selectingPiece = "S"
                if (currentPlayer == 2 && p2PieceLeft.get(0) > 0) selectingPiece = "S"
                currentInfoView.setText("Player " + currentPlayer + " - select " + selectingPiece + " piece")
            } else if (buttonClicked.id == R.id.selectMButton) {
                if (currentPlayer == 1 && p1PieceLeft.get(1) > 0) selectingPiece = "M"
                if (currentPlayer == 2 && p2PieceLeft.get(1) > 0) selectingPiece = "M"
                currentInfoView.setText("Player " + currentPlayer + " - select " + selectingPiece + " piece")
            } else if (buttonClicked.id == R.id.selectLButton) {
                if (currentPlayer == 1 && p1PieceLeft.get(2) > 0) selectingPiece = "L"
                if (currentPlayer == 2 && p2PieceLeft.get(2) > 0) selectingPiece = "L"
                currentInfoView.setText("Player " + currentPlayer + " - select " + selectingPiece + " piece")
            }
        }
       }

       lateinit var pieceButton : Button
       var currentPlayer = 1
       var p1PieceLeft = arrayOf<Int>(2, 2, 2)
       var p2PieceLeft = arrayOf<Int>(2, 2, 2)
       var selectingPiece = "S"
        var winner = -1

       private fun gameplay(cellID: Int, buttonClicked: Button) {
           val currentInfoView: TextView = findViewById(R.id.currentInfoView)
           if (cellArray[cellID].isEmpty()) {
               cellArray[cellID].add(currentPlayer.toString() + selectingPiece.get(0))
               buttonClicked.text = "o"
               when (selectingPiece.get(0)) {
                   'S' -> buttonClicked.setTextSize(1, 18F)
                   'M' -> buttonClicked.setTextSize(1, 30F)
                   'L' -> buttonClicked.setTextSize(1, 44F)
               }
               if (currentPlayer == 1) {
                   buttonClicked.setTextColor(Color.parseColor("#3F51B5"))
                   if (selectingPiece.length == 1)
                   when (selectingPiece.get(0)) {
                       'S' -> p1PieceLeft.set(0, p1PieceLeft.get(0)-1)
                       'M' -> p1PieceLeft.set(1, p1PieceLeft.get(1)-1)
                       'L' -> p1PieceLeft.set(2, p1PieceLeft.get(2)-1)
                   }
               } else {
                   buttonClicked.setTextColor(Color.parseColor("#FF5722"))
                   if (selectingPiece.length == 1)
                   when (selectingPiece.get(0)) {
                       'S' -> p2PieceLeft.set(0, p2PieceLeft.get(0)-1)
                       'M' -> p2PieceLeft.set(1, p2PieceLeft.get(1)-1)
                       'L' -> p2PieceLeft.set(2, p2PieceLeft.get(2)-1)
                   }
               }
               if (selectingPiece.length > 1) {
                   cellArray[selectingPiece.get(1).toString().toInt()].removeAt(cellArray[selectingPiece.get(1).toString().toInt()].size-1)
                   pieceButton.setText("")
                   if (!cellArray[selectingPiece.get(1).toString().toInt()].isEmpty()) {
                       pieceButton.setText("o")
                        when (cellArray[selectingPiece.get(1).toString().toInt()].get(cellArray[selectingPiece.get(1).toString().toInt()].size-1).get(1)) {
                            'S' -> pieceButton.setTextSize(1, 18F)
                            'M' -> pieceButton.setTextSize(1, 30F)
                            'L' -> pieceButton.setTextSize(1, 44F)
                        }
                        if (cellArray[selectingPiece.get(1).toString().toInt()].get(cellArray[selectingPiece.get(1).toString().toInt()].size-1).get(0) == '1')
                            pieceButton.setTextColor(Color.parseColor("#3F51B5"))
                       else
                            pieceButton.setTextColor(Color.parseColor("#FF5722"))
                   }
               }
               winCondCheck(cellID)

           } else if (cellArray[cellID].get(cellArray[cellID].size-1).get(0).toString() == currentPlayer.toString()) {
               selectingPiece = cellArray[cellID].get(cellArray[cellID].size-1).get(1) + cellID.toString()
               currentInfoView.setText("Player " + currentPlayer + " - select " + selectingPiece + " piece")
                pieceButton = buttonClicked

           } else if (cellArray[cellID].size < 3) {

               if (selectingPiece.get(0) == 'M' && cellArray[cellID].get(cellArray[cellID].size-1).get(1) == 'S'
                   || selectingPiece.get(0) == 'L' && cellArray[cellID].get(cellArray[cellID].size-1).get(1) != 'L') {

                   cellArray[cellID].add(currentPlayer.toString() + selectingPiece.get(0))
                   buttonClicked.text = "o"
                   when (selectingPiece.get(0)) {
                       'S' -> buttonClicked.setTextSize(1, 18F)
                       'M' -> buttonClicked.setTextSize(1, 30F)
                       'L' -> buttonClicked.setTextSize(1, 44F)
                   }
                   if (currentPlayer == 1) {
                       buttonClicked.setTextColor(Color.parseColor("#3F51B5"))
                       if (selectingPiece.length == 1)
                       when (selectingPiece.get(0)) {
                           'S' -> p1PieceLeft.set(0, p1PieceLeft.get(0)-1)
                           'M' -> p1PieceLeft.set(1, p1PieceLeft.get(1)-1)
                           'L' -> p1PieceLeft.set(2, p1PieceLeft.get(2)-1)
                       }
                   } else {
                       buttonClicked.setTextColor(Color.parseColor("#FF5722"))
                       if (selectingPiece.length == 1)
                       when (selectingPiece.get(0)) {
                           'S' -> p2PieceLeft.set(0, p2PieceLeft.get(0)-1)
                           'M' -> p2PieceLeft.set(1, p2PieceLeft.get(1)-1)
                           'L' -> p2PieceLeft.set(2, p2PieceLeft.get(2)-1)
                       }
                   }
                   if (selectingPiece.length > 1) {
                       cellArray[selectingPiece.get(1).toString().toInt()].removeAt(cellArray[selectingPiece.get(1).toString().toInt()].size-1)
                       pieceButton.setText("")
                       if (!cellArray[selectingPiece.get(1).toString().toInt()].isEmpty()) {
                           pieceButton.setText("o")
                           when (cellArray[selectingPiece.get(1).toString().toInt()].get(cellArray[selectingPiece.get(1).toString().toInt()].size-1).get(1)) {
                               'S' -> pieceButton.setTextSize(1, 18F)
                               'M' -> pieceButton.setTextSize(1, 30F)
                               'L' -> pieceButton.setTextSize(1, 44F)
                           }
                           if (cellArray[selectingPiece.get(1).toString().toInt()].get(cellArray[selectingPiece.get(1).toString().toInt()].size-1).get(0) == '1')
                               pieceButton.setTextColor(Color.parseColor("#3F51B5"))
                           else
                               pieceButton.setTextColor(Color.parseColor("#FF5722"))
                       }
                   }
                   winCondCheck(cellID)
               }
           }
       }

       private fun winCondCheck(cellID: Int) {
           val currentInfoView: TextView = findViewById(R.id.currentInfoView)
           val sView: TextView = findViewById(R.id.sView)
           val mView: TextView = findViewById(R.id.mView)
           val lView: TextView = findViewById(R.id.lView)
           val selectSButton: TextView = findViewById(R.id.selectSButton)
           val selectMButton: TextView = findViewById(R.id.selectMButton)
           val selectLButton: TextView = findViewById(R.id.selectLButton)
           val otherPlayer = (currentPlayer % 2) + 1

           if (selectingPiece.length > 1 && !cellArray[selectingPiece.get(1).toString().toInt()].isEmpty()) {
               if (selectingPiece.get(1).toString().toInt() == 0) {
                   if (!cellArray[1].isEmpty() && !cellArray[2].isEmpty()) {
                       if (cellArray[1].get(cellArray[1].size - 1).get(0).toString() == otherPlayer.toString() &&
                           cellArray[2].get(cellArray[2].size - 1).get(0).toString() == otherPlayer.toString()) {
                           winner = otherPlayer
                       }
                   } else if (!cellArray[3].isEmpty() && !cellArray[6].isEmpty()) {
                       if (cellArray[3].get(cellArray[3].size - 1).get(0).toString() == otherPlayer.toString() &&
                           cellArray[6].get(cellArray[6].size - 1).get(0).toString() == otherPlayer.toString()) {
                           winner = otherPlayer
                       }
                   } else if (!cellArray[4].isEmpty() && !cellArray[8].isEmpty()) {
                       if (cellArray[4].get(cellArray[4].size - 1).get(0).toString() == otherPlayer.toString() &&
                           cellArray[8].get(cellArray[8].size - 1).get(0).toString() == otherPlayer.toString()) {
                           winner = otherPlayer
                       }
                   }
               } else if (selectingPiece.get(1).toString().toInt() == 1) {
                   if (!cellArray[0].isEmpty() && !cellArray[2].isEmpty() &&
                       cellArray[0].get(cellArray[0].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[2].get(cellArray[2].size - 1).get(0).toString() == otherPlayer.toString() ||

                       !cellArray[4].isEmpty() && !cellArray[7].isEmpty() &&
                       cellArray[4].get(cellArray[4].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[7].get(cellArray[7].size - 1).get(0).toString() == otherPlayer.toString()) {
                       winner = otherPlayer
                   }
               } else if (selectingPiece.get(1).toString().toInt() == 2) {
                   if (!cellArray[0].isEmpty() && !cellArray[1].isEmpty() &&
                       cellArray[0].get(cellArray[0].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[1].get(cellArray[1].size - 1).get(0).toString() == otherPlayer.toString() ||

                       !cellArray[4].isEmpty() && !cellArray[6].isEmpty() &&
                       cellArray[4].get(cellArray[4].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[6].get(cellArray[6].size - 1).get(0).toString() == otherPlayer.toString() ||

                       !cellArray[5].isEmpty() && !cellArray[8].isEmpty() &&
                       cellArray[5].get(cellArray[5].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[8].get(cellArray[8].size - 1).get(0).toString() == otherPlayer.toString()) {
                       winner = otherPlayer
                   }
               } else if (selectingPiece.get(1).toString().toInt() == 3) {
                   if (!cellArray[4].isEmpty() && !cellArray[5].isEmpty() &&
                       cellArray[4].get(cellArray[4].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[5].get(cellArray[5].size - 1).get(0).toString() == otherPlayer.toString() ||

                       !cellArray[0].isEmpty() && !cellArray[6].isEmpty() &&
                       cellArray[0].get(cellArray[0].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[6].get(cellArray[6].size - 1).get(0).toString() == otherPlayer.toString()) {
                       winner = otherPlayer
                   }
               } else if (selectingPiece.get(1).toString().toInt() == 4) {
                   if (!cellArray[0].isEmpty() && !cellArray[8].isEmpty()) {
                       if (cellArray[0].get(cellArray[0].size - 1).get(0).toString() == otherPlayer.toString() &&
                           cellArray[8].get(cellArray[8].size - 1).get(0).toString() == otherPlayer.toString()) {
                           winner = otherPlayer
                       }
                   } else if (!cellArray[1].isEmpty() && !cellArray[7].isEmpty()) {
                       if (cellArray[1].get(cellArray[1].size - 1).get(0).toString() == otherPlayer.toString() &&
                           cellArray[7].get(cellArray[7].size - 1).get(0).toString() == otherPlayer.toString()) {
                           winner = otherPlayer
                       }
                   } else if (!cellArray[2].isEmpty() && !cellArray[6].isEmpty()) {
                       if (cellArray[2].get(cellArray[2].size - 1).get(0).toString() == otherPlayer.toString() &&
                           cellArray[6].get(cellArray[6].size - 1).get(0).toString() == otherPlayer.toString()) {
                           winner = otherPlayer
                       }
                   } else if (!cellArray[3].isEmpty() && !cellArray[5].isEmpty()) {
                       if (cellArray[3].get(cellArray[3].size - 1).get(0).toString() == otherPlayer.toString() &&
                           cellArray[5].get(cellArray[5].size - 1).get(0).toString() == otherPlayer.toString()) {
                           winner = otherPlayer
                       }
                   }
               } else if (selectingPiece.get(1).toString().toInt() == 5) {
                   if (!cellArray[3].isEmpty() && !cellArray[4].isEmpty() &&
                       cellArray[3].get(cellArray[3].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[4].get(cellArray[4].size - 1).get(0).toString() == otherPlayer.toString() ||

                       !cellArray[2].isEmpty() && !cellArray[8].isEmpty() &&
                       cellArray[2].get(cellArray[2].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[8].get(cellArray[8].size - 1).get(0).toString() == otherPlayer.toString()) {
                       winner = otherPlayer
                   }
               } else if (selectingPiece.get(1).toString().toInt() == 6) {
                   if (!cellArray[0].isEmpty() && !cellArray[3].isEmpty() &&
                       cellArray[0].get(cellArray[0].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[3].get(cellArray[3].size - 1).get(0).toString() == otherPlayer.toString() ||

                       !cellArray[4].isEmpty() && !cellArray[2].isEmpty() &&
                       cellArray[4].get(cellArray[4].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[2].get(cellArray[2].size - 1).get(0).toString() == otherPlayer.toString() ||

                       !cellArray[7].isEmpty() && !cellArray[8].isEmpty() &&
                       cellArray[7].get(cellArray[7].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[8].get(cellArray[8].size - 1).get(0).toString() == otherPlayer.toString()) {
                       winner = otherPlayer
                   }
               } else if (selectingPiece.get(1).toString().toInt() == 7) {
                   if (!cellArray[1].isEmpty() && !cellArray[4].isEmpty() &&
                       cellArray[1].get(cellArray[1].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[4].get(cellArray[4].size - 1).get(0).toString() == otherPlayer.toString() ||

                       !cellArray[6].isEmpty() && !cellArray[8].isEmpty() &&
                       cellArray[6].get(cellArray[6].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[8].get(cellArray[8].size - 1).get(0).toString() == otherPlayer.toString()) {
                       winner = otherPlayer
                   }
               } else if (selectingPiece.get(1).toString().toInt() == 8) {
                   if (!cellArray[0].isEmpty() && !cellArray[4].isEmpty() &&
                       cellArray[0].get(cellArray[0].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[4].get(cellArray[4].size - 1).get(0).toString() == otherPlayer.toString() ||

                       !cellArray[2].isEmpty() && !cellArray[5].isEmpty() &&
                       cellArray[2].get(cellArray[2].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[5].get(cellArray[5].size - 1).get(0).toString() == otherPlayer.toString() ||

                       !cellArray[6].isEmpty() && !cellArray[7].isEmpty() &&
                       cellArray[6].get(cellArray[6].size - 1).get(0).toString() == otherPlayer.toString() &&
                       cellArray[7].get(cellArray[7].size - 1).get(0).toString() == otherPlayer.toString()) {
                       winner = otherPlayer
                   }
               }
           } else if (winner == -1) {
               if (cellID == 0) {
                   if (!cellArray[1].isEmpty() && !cellArray[2].isEmpty()) {
                       if (cellArray[1].get(cellArray[1].size - 1).get(0)
                               .toString() == currentPlayer.toString() &&
                           cellArray[2].get(cellArray[2].size - 1).get(0)
                               .toString() == currentPlayer.toString()
                       ) {
                           winner = currentPlayer
                       }
                   } else if (!cellArray[3].isEmpty() && !cellArray[6].isEmpty()) {
                       if (cellArray[3].get(cellArray[3].size - 1).get(0)
                               .toString() == currentPlayer.toString() &&
                           cellArray[6].get(cellArray[6].size - 1).get(0)
                               .toString() == currentPlayer.toString()
                       ) {
                           winner = currentPlayer
                       }
                   } else if (!cellArray[4].isEmpty() && !cellArray[8].isEmpty()) {
                       if (cellArray[4].get(cellArray[4].size - 1).get(0)
                               .toString() == currentPlayer.toString() &&
                           cellArray[8].get(cellArray[8].size - 1).get(0)
                               .toString() == currentPlayer.toString()
                       ) {
                           winner = currentPlayer
                       }
                   }
               } else if (cellID == 1) {
                   if (!cellArray[0].isEmpty() && !cellArray[2].isEmpty() &&
                       cellArray[0].get(cellArray[0].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[2].get(cellArray[2].size - 1).get(0)
                           .toString() == currentPlayer.toString() ||

                       !cellArray[4].isEmpty() && !cellArray[7].isEmpty() &&
                       cellArray[4].get(cellArray[4].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[7].get(cellArray[7].size - 1).get(0)
                           .toString() == currentPlayer.toString()
                   ) {
                       winner = currentPlayer
                   }
               } else if (cellID == 2) {
                   if (!cellArray[0].isEmpty() && !cellArray[1].isEmpty() &&
                       cellArray[0].get(cellArray[0].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[1].get(cellArray[1].size - 1).get(0)
                           .toString() == currentPlayer.toString() ||

                       !cellArray[4].isEmpty() && !cellArray[6].isEmpty() &&
                       cellArray[4].get(cellArray[4].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[6].get(cellArray[6].size - 1).get(0)
                           .toString() == currentPlayer.toString() ||

                       !cellArray[5].isEmpty() && !cellArray[8].isEmpty() &&
                       cellArray[5].get(cellArray[5].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[8].get(cellArray[8].size - 1).get(0)
                           .toString() == currentPlayer.toString()
                   ) {
                       winner = currentPlayer
                   }
               } else if (cellID == 3) {
                   if (!cellArray[4].isEmpty() && !cellArray[5].isEmpty() &&
                       cellArray[4].get(cellArray[4].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[5].get(cellArray[5].size - 1).get(0)
                           .toString() == currentPlayer.toString() ||

                       !cellArray[0].isEmpty() && !cellArray[6].isEmpty() &&
                       cellArray[0].get(cellArray[0].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[6].get(cellArray[6].size - 1).get(0)
                           .toString() == currentPlayer.toString()
                   ) {
                       winner = currentPlayer
                   }
               } else if (cellID == 4) {
                   if (!cellArray[0].isEmpty() && !cellArray[8].isEmpty()) {
                       if (cellArray[0].get(cellArray[0].size - 1).get(0)
                               .toString() == currentPlayer.toString() &&
                           cellArray[8].get(cellArray[8].size - 1).get(0)
                               .toString() == currentPlayer.toString()
                       ) {
                           winner = currentPlayer
                       }
                   } else if (!cellArray[1].isEmpty() && !cellArray[7].isEmpty()) {
                       if (cellArray[1].get(cellArray[1].size - 1).get(0)
                               .toString() == currentPlayer.toString() &&
                           cellArray[7].get(cellArray[7].size - 1).get(0)
                               .toString() == currentPlayer.toString()
                       ) {
                           winner = currentPlayer
                       }
                   } else if (!cellArray[2].isEmpty() && !cellArray[6].isEmpty()) {
                       if (cellArray[2].get(cellArray[2].size - 1).get(0)
                               .toString() == currentPlayer.toString() &&
                           cellArray[6].get(cellArray[6].size - 1).get(0)
                               .toString() == currentPlayer.toString()
                       ) {
                           winner = currentPlayer
                       }
                   } else if (!cellArray[3].isEmpty() && !cellArray[5].isEmpty()) {
                       if (cellArray[3].get(cellArray[3].size - 1).get(0)
                               .toString() == currentPlayer.toString() &&
                           cellArray[5].get(cellArray[5].size - 1).get(0)
                               .toString() == currentPlayer.toString()
                       ) {
                           winner = currentPlayer
                       }
                   }
               } else if (cellID == 5) {
                   if (!cellArray[3].isEmpty() && !cellArray[4].isEmpty() &&
                       cellArray[3].get(cellArray[3].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[4].get(cellArray[4].size - 1).get(0)
                           .toString() == currentPlayer.toString() ||

                       !cellArray[2].isEmpty() && !cellArray[8].isEmpty() &&
                       cellArray[2].get(cellArray[2].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[8].get(cellArray[8].size - 1).get(0)
                           .toString() == currentPlayer.toString()
                   ) {
                       winner = currentPlayer
                   }
               } else if (cellID == 6) {
                   if (!cellArray[0].isEmpty() && !cellArray[3].isEmpty() &&
                       cellArray[0].get(cellArray[0].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[3].get(cellArray[3].size - 1).get(0)
                           .toString() == currentPlayer.toString() ||

                       !cellArray[4].isEmpty() && !cellArray[2].isEmpty() &&
                       cellArray[4].get(cellArray[4].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[2].get(cellArray[2].size - 1).get(0)
                           .toString() == currentPlayer.toString() ||

                       !cellArray[7].isEmpty() && !cellArray[8].isEmpty() &&
                       cellArray[7].get(cellArray[7].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[8].get(cellArray[8].size - 1).get(0)
                           .toString() == currentPlayer.toString()
                   ) {
                       winner = currentPlayer
                   }
               } else if (cellID == 7) {
                   if (!cellArray[1].isEmpty() && !cellArray[4].isEmpty() &&
                       cellArray[1].get(cellArray[1].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[4].get(cellArray[4].size - 1).get(0)
                           .toString() == currentPlayer.toString() ||

                       !cellArray[6].isEmpty() && !cellArray[8].isEmpty() &&
                       cellArray[6].get(cellArray[6].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[8].get(cellArray[8].size - 1).get(0)
                           .toString() == currentPlayer.toString()
                   ) {
                       winner = currentPlayer
                   }
               } else if (cellID == 8) {
                   if (!cellArray[0].isEmpty() && !cellArray[4].isEmpty() &&
                       cellArray[0].get(cellArray[0].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[4].get(cellArray[4].size - 1).get(0)
                           .toString() == currentPlayer.toString() ||

                       !cellArray[2].isEmpty() && !cellArray[5].isEmpty() &&
                       cellArray[2].get(cellArray[2].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[5].get(cellArray[5].size - 1).get(0)
                           .toString() == currentPlayer.toString() ||

                       !cellArray[6].isEmpty() && !cellArray[7].isEmpty() &&
                       cellArray[6].get(cellArray[6].size - 1).get(0)
                           .toString() == currentPlayer.toString() &&
                       cellArray[7].get(cellArray[7].size - 1).get(0)
                           .toString() == currentPlayer.toString()
                   ) {
                       winner = currentPlayer
                   }
               }
           }
           if (winner == -1) {
               currentPlayer = (currentPlayer % 2) + 1
               if (currentPlayer == 1) {
                   sView.setText("S piece: " + p1PieceLeft.get(0))
                   selectSButton.setTextColor(Color.parseColor("#3F51B5"))
                   mView.setText("M piece: " + p1PieceLeft.get(1))
                   selectMButton.setTextColor(Color.parseColor("#3F51B5"))
                   lView.setText("L piece: " + p1PieceLeft.get(2))
                   selectLButton.setTextColor(Color.parseColor("#3F51B5"))
                   if (p1PieceLeft.get(0) > 0) {
                       selectingPiece = "S"
                       currentInfoView.setText("Player 1 - select S piece")
                   } else if (p1PieceLeft.get(1) > 0) {
                       selectingPiece = "M"
                       currentInfoView.setText("Player 1 - select M piece")
                   } else {
                       selectingPiece = "L"
                       currentInfoView.setText("Player 1 - select L piece")
                   }
               } else {
                   sView.setText("S piece: " + p2PieceLeft.get(0))
                   selectSButton.setTextColor(Color.parseColor("#FF5722"))
                   mView.setText("M piece: " + p2PieceLeft.get(1))
                   selectMButton.setTextColor(Color.parseColor("#FF5722"))
                   lView.setText("L piece: " + p2PieceLeft.get(2))
                   selectLButton.setTextColor(Color.parseColor("#FF5722"))
                   if (p2PieceLeft.get(0) > 0) {
                       selectingPiece = "S"
                       currentInfoView.setText("Player 2 - select S piece")
                   } else if (p2PieceLeft.get(1) > 0) {
                       selectingPiece = "M"
                       currentInfoView.setText("Player 2 - select M piece")
                   } else {
                       selectingPiece = "L"
                       currentInfoView.setText("Player 2 - select L piece")
                   }
               }
           } else {
               Toast.makeText(this, "Player" + winner + " has won!", Toast.LENGTH_LONG).show()
           }
       }
}
